<?php

namespace Database\Factories;

use App\Models\StudyMode;
use Illuminate\Database\Eloquent\Factories\Factory;

class StudyModeFactory extends Factory
{
    protected $model = StudyMode::class;

    public function definition(): array
    {
        return [

        ];
    }
}
