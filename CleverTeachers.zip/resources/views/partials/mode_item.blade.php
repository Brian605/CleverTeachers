<div class="col-md-4">
    <div class="card">
        <div class="card-body">
            <div class="row d-flex justify-content-evenly">
                <div class="col-md-12 col-10">
                    <h6>{{$category->name}}</h6>
                    <div class="text-end">
                        <a href="/modes/remove/{{$category->id}}" class="btn btn-danger btn-sm">Delete</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

