<!-- [ Pre-loader ] start -->
<div class="loader-bg">
    <div class="pc-loader">
        <div class="loader-fill"></div>
    </div>
</div>
<!-- [ Pre-loader ] End -->
